﻿namespace DATA_VIZ
{
    partial class frnDataViz
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnVis = new System.Windows.Forms.Button();
            this.tabDisplay = new System.Windows.Forms.TabControl();
            this.tabVisual = new System.Windows.Forms.TabPage();
            this.tabData = new System.Windows.Forms.TabPage();
            this.lstDataInput = new System.Windows.Forms.ListBox();
            this.lblTotalNum = new System.Windows.Forms.Label();
            this.lblAverage = new System.Windows.Forms.Label();
            this.lblMax = new System.Windows.Forms.Label();
            this.lblMin = new System.Windows.Forms.Label();
            this.panVis = new System.Windows.Forms.Panel();
            this.tabDisplay.SuspendLayout();
            this.tabVisual.SuspendLayout();
            this.tabData.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnVis
            // 
            this.btnVis.Location = new System.Drawing.Point(12, 12);
            this.btnVis.Name = "btnVis";
            this.btnVis.Size = new System.Drawing.Size(89, 31);
            this.btnVis.TabIndex = 0;
            this.btnVis.Text = "Visualize Data";
            this.btnVis.UseVisualStyleBackColor = true;
            this.btnVis.Click += new System.EventHandler(this.btnVis_Click);
            // 
            // tabDisplay
            // 
            this.tabDisplay.Controls.Add(this.tabVisual);
            this.tabDisplay.Controls.Add(this.tabData);
            this.tabDisplay.Location = new System.Drawing.Point(1, 49);
            this.tabDisplay.Name = "tabDisplay";
            this.tabDisplay.SelectedIndex = 0;
            this.tabDisplay.Size = new System.Drawing.Size(753, 445);
            this.tabDisplay.TabIndex = 0;
            // 
            // tabVisual
            // 
            this.tabVisual.Controls.Add(this.panVis);
            this.tabVisual.Location = new System.Drawing.Point(4, 22);
            this.tabVisual.Name = "tabVisual";
            this.tabVisual.Padding = new System.Windows.Forms.Padding(3);
            this.tabVisual.Size = new System.Drawing.Size(745, 419);
            this.tabVisual.TabIndex = 0;
            this.tabVisual.Text = "Visualization";
            this.tabVisual.UseVisualStyleBackColor = true;
            // 
            // tabData
            // 
            this.tabData.Controls.Add(this.lstDataInput);
            this.tabData.Location = new System.Drawing.Point(4, 22);
            this.tabData.Name = "tabData";
            this.tabData.Padding = new System.Windows.Forms.Padding(3);
            this.tabData.Size = new System.Drawing.Size(745, 419);
            this.tabData.TabIndex = 1;
            this.tabData.Text = "Display Stats & Data";
            this.tabData.UseVisualStyleBackColor = true;
            // 
            // lstDataInput
            // 
            this.lstDataInput.FormattingEnabled = true;
            this.lstDataInput.Location = new System.Drawing.Point(3, 0);
            this.lstDataInput.Name = "lstDataInput";
            this.lstDataInput.Size = new System.Drawing.Size(753, 433);
            this.lstDataInput.TabIndex = 0;
            // 
            // lblTotalNum
            // 
            this.lblTotalNum.AutoSize = true;
            this.lblTotalNum.Location = new System.Drawing.Point(246, 33);
            this.lblTotalNum.Name = "lblTotalNum";
            this.lblTotalNum.Size = new System.Drawing.Size(82, 13);
            this.lblTotalNum.TabIndex = 2;
            this.lblTotalNum.Text = "Total Numbers :";
            // 
            // lblAverage
            // 
            this.lblAverage.AutoSize = true;
            this.lblAverage.Location = new System.Drawing.Point(431, 33);
            this.lblAverage.Name = "lblAverage";
            this.lblAverage.Size = new System.Drawing.Size(53, 13);
            this.lblAverage.TabIndex = 3;
            this.lblAverage.Text = "Average :";
            // 
            // lblMax
            // 
            this.lblMax.AutoSize = true;
            this.lblMax.Location = new System.Drawing.Point(326, 9);
            this.lblMax.Name = "lblMax";
            this.lblMax.Size = new System.Drawing.Size(57, 13);
            this.lblMax.TabIndex = 4;
            this.lblMax.Text = "Maximum :";
            // 
            // lblMin
            // 
            this.lblMin.AutoSize = true;
            this.lblMin.Location = new System.Drawing.Point(534, 9);
            this.lblMin.Name = "lblMin";
            this.lblMin.Size = new System.Drawing.Size(54, 13);
            this.lblMin.TabIndex = 5;
            this.lblMin.Text = "Minimum :";
            // 
            // panVis
            // 
            this.panVis.Location = new System.Drawing.Point(0, 6);
            this.panVis.Name = "panVis";
            this.panVis.Size = new System.Drawing.Size(656, 384);
            this.panVis.TabIndex = 0;
            // 
            // frnDataViz
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(766, 506);
            this.Controls.Add(this.lblMin);
            this.Controls.Add(this.lblMax);
            this.Controls.Add(this.lblAverage);
            this.Controls.Add(this.lblTotalNum);
            this.Controls.Add(this.tabDisplay);
            this.Controls.Add(this.btnVis);
            this.Name = "frnDataViz";
            this.Text = "Burch DataViz";
            this.tabDisplay.ResumeLayout(false);
            this.tabVisual.ResumeLayout(false);
            this.tabData.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnVis;
        private System.Windows.Forms.TabControl tabDisplay;
        private System.Windows.Forms.TabPage tabVisual;
        private System.Windows.Forms.TabPage tabData;
        private System.Windows.Forms.Label lblTotalNum;
        private System.Windows.Forms.Label lblAverage;
        private System.Windows.Forms.Label lblMax;
        private System.Windows.Forms.Label lblMin;
        private System.Windows.Forms.ListBox lstDataInput;
        private System.Windows.Forms.Panel panVis;
    }
}

