﻿using System;
using System.IO;
using System.Drawing;
using System.Windows.Forms;

///////////////////////
//  12/05/17
// Brendan Burch
// CIS 202
// Data visualization program

namespace DATA_VIZ
{
    public partial class frnDataViz : Form
    {
        //scope level vars//

        Graphics gr;
        Brush br;
        StreamReader rdr;
        int min = 0;
        int max = 0;
        int[] list = new int [TotalNum]; //total numbers//
        const int TotalNum = 1000;
        float avg = 0; //var for average vaule//


    
        public frnDataViz() //initialize frm DataViz//
        {
            InitializeComponent();
        }

        private void btnVis_Click(object sender, EventArgs e) //Code for visualize data button//
        {
            try
            {
                rdr = new StreamReader("DATA.TXT");
                for(int i = 0; i < TotalNum; i++)
                {
                    list[i] = int.Parse(rdr.ReadLine());
                    lstDataInput.Items.Add((i + 1) + " : " + list[i]);
                }
                rdr.Close();
                Stats();
                Draw();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Stats() //stats method//
        {
            min = list[0];
            max = list[0];
            int Sum = 0;

            for (int i = 0; i < TotalNum; i++)
            {
                if(list [i] < min)
                {
                    min = list[i];
                }
                if(list [i] > max)
                {
                    max = list[i];
                }

                Sum += list[i];
             }
                avg = Sum / (float)TotalNum;
                lblTotalNum.Text = " Numbers =  " + TotalNum;
                lblAverage.Text = " Average " + avg;
                lblMin.Text = " Min = " + min;
                lblMax.Text = " Max = " + max;
            
        }

        private Color BrushCol(int Num) //if statements for picking  bar color based on Num return//
        {
            if ((float)Num == min)
            {
                return Color.Black;
            }
            else if ((float)Num == max)
            {
                return Color.Blue;
            }
            else if ((float)Num <= avg)
            {
                return Color.Red;
            }
            else
            {
                return Color.Green;
            }
        }

        private void Draw() //method for creating bars for graph based on information from stats()//
        {
            float PlaceCT = 0;
            float standwidth = panVis.Width / (float)TotalNum; //sets dimensions to fill panel//
            float ratio = panVis.Height / (float)max;//sets max height equal to height of panel//
            gr = panVis.CreateGraphics();

            for(int i = 0; i < TotalNum; i++)
            {
                br = new SolidBrush(BrushCol(list[i]));//picks brush color based on BrushCol()//
                float x = PlaceCT; //x value//
                PlaceCT += standwidth;//move to next value of graph by 1//
                float h = list[i] * ratio;//height of panel//
                float y = panVis.Height-h;//base of graph = zero//
                float w = standwidth;// " " line 104//
                gr.FillRectangle(br, x, y, w, h); // fills rectangle based on values//
            }
            br = new SolidBrush(Color.Orange);
            /////////////////////////
            //Center Line Variables//
            float xc = 0; 
            float yc = panVis.Height - (avg * ratio);
            float hc = 2;
            float wc = panVis.Width;
            gr.FillRectangle(br, xc, yc, wc, hc);//fills rectangle based on variables//
        }

    }
    
}
