﻿namespace Say_Hello
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnHello = new System.Windows.Forms.Button();
            this.btnGoodbye = new System.Windows.Forms.Button();
            this.lblIn = new System.Windows.Forms.Label();
            this.textIn = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // btnHello
            // 
            this.btnHello.BackColor = System.Drawing.Color.LawnGreen;
            this.btnHello.Location = new System.Drawing.Point(460, 42);
            this.btnHello.Name = "btnHello";
            this.btnHello.Size = new System.Drawing.Size(173, 124);
            this.btnHello.TabIndex = 0;
            this.btnHello.Text = "Say Hello";
            this.btnHello.UseVisualStyleBackColor = false;
            this.btnHello.Click += new System.EventHandler(this.btnHello_Click);
            // 
            // btnGoodbye
            // 
            this.btnGoodbye.BackColor = System.Drawing.Color.Red;
            this.btnGoodbye.Location = new System.Drawing.Point(460, 285);
            this.btnGoodbye.Name = "btnGoodbye";
            this.btnGoodbye.Size = new System.Drawing.Size(173, 124);
            this.btnGoodbye.TabIndex = 1;
            this.btnGoodbye.Text = "Say Goodbye!";
            this.btnGoodbye.UseVisualStyleBackColor = false;
            this.btnGoodbye.Click += new System.EventHandler(this.btnGoodbye_Click);
            // 
            // lblIn
            // 
            this.lblIn.AutoSize = true;
            this.lblIn.Location = new System.Drawing.Point(278, 212);
            this.lblIn.Name = "lblIn";
            this.lblIn.Size = new System.Drawing.Size(91, 13);
            this.lblIn.TabIndex = 2;
            this.lblIn.Text = "Enter Your Name:";
            // 
            // textIn
            // 
            this.textIn.Location = new System.Drawing.Point(445, 209);
            this.textIn.Name = "textIn";
            this.textIn.Size = new System.Drawing.Size(187, 20);
            this.textIn.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cyan;
            this.ClientSize = new System.Drawing.Size(847, 508);
            this.Controls.Add(this.textIn);
            this.Controls.Add(this.lblIn);
            this.Controls.Add(this.btnGoodbye);
            this.Controls.Add(this.btnHello);
            this.Name = "Form1";
            this.Text = "BBurch";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnHello;
        private System.Windows.Forms.Button btnGoodbye;
        private System.Windows.Forms.Label lblIn;
        private System.Windows.Forms.TextBox textIn;
    }
}

