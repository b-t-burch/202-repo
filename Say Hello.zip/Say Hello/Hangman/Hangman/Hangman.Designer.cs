﻿namespace Hangman
{
    partial class Hangman
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnA = new System.Windows.Forms.Button();
            this.btnB = new System.Windows.Forms.Button();
            this.btnC = new System.Windows.Forms.Button();
            this.btnD = new System.Windows.Forms.Button();
            this.btnE = new System.Windows.Forms.Button();
            this.btnF = new System.Windows.Forms.Button();
            this.btnG = new System.Windows.Forms.Button();
            this.btnH = new System.Windows.Forms.Button();
            this.btnI = new System.Windows.Forms.Button();
            this.btnJ = new System.Windows.Forms.Button();
            this.btnK = new System.Windows.Forms.Button();
            this.btnL = new System.Windows.Forms.Button();
            this.btnM = new System.Windows.Forms.Button();
            this.btnN = new System.Windows.Forms.Button();
            this.btnR = new System.Windows.Forms.Button();
            this.btnQ = new System.Windows.Forms.Button();
            this.btnP = new System.Windows.Forms.Button();
            this.btnO = new System.Windows.Forms.Button();
            this.btnX = new System.Windows.Forms.Button();
            this.btnW = new System.Windows.Forms.Button();
            this.btnV = new System.Windows.Forms.Button();
            this.btnU = new System.Windows.Forms.Button();
            this.btnT = new System.Windows.Forms.Button();
            this.btnZ = new System.Windows.Forms.Button();
            this.btnY = new System.Windows.Forms.Button();
            this.btnS = new System.Windows.Forms.Button();
            this.txtWord = new System.Windows.Forms.TextBox();
            this.lblInput = new System.Windows.Forms.Label();
            this.lblLetter = new System.Windows.Forms.Label();
            this.txtOut = new System.Windows.Forms.TextBox();
            this.btnEncrypt = new System.Windows.Forms.Button();
            this.lblOutput = new System.Windows.Forms.Label();
            this.txtSolve = new System.Windows.Forms.TextBox();
            this.lblSolve = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnA
            // 
            this.btnA.Location = new System.Drawing.Point(16, 294);
            this.btnA.Name = "btnA";
            this.btnA.Size = new System.Drawing.Size(37, 32);
            this.btnA.TabIndex = 0;
            this.btnA.Text = "A";
            this.btnA.UseVisualStyleBackColor = true;
            // 
            // btnB
            // 
            this.btnB.Location = new System.Drawing.Point(59, 294);
            this.btnB.Name = "btnB";
            this.btnB.Size = new System.Drawing.Size(37, 32);
            this.btnB.TabIndex = 1;
            this.btnB.Text = "B";
            this.btnB.UseVisualStyleBackColor = true;
            // 
            // btnC
            // 
            this.btnC.Location = new System.Drawing.Point(102, 294);
            this.btnC.Name = "btnC";
            this.btnC.Size = new System.Drawing.Size(37, 32);
            this.btnC.TabIndex = 2;
            this.btnC.Text = "C";
            this.btnC.UseVisualStyleBackColor = true;
            // 
            // btnD
            // 
            this.btnD.Location = new System.Drawing.Point(145, 294);
            this.btnD.Name = "btnD";
            this.btnD.Size = new System.Drawing.Size(37, 32);
            this.btnD.TabIndex = 3;
            this.btnD.Text = "D";
            this.btnD.UseVisualStyleBackColor = true;
            // 
            // btnE
            // 
            this.btnE.Location = new System.Drawing.Point(188, 294);
            this.btnE.Name = "btnE";
            this.btnE.Size = new System.Drawing.Size(37, 32);
            this.btnE.TabIndex = 4;
            this.btnE.Text = "E";
            this.btnE.UseVisualStyleBackColor = true;
            // 
            // btnF
            // 
            this.btnF.Location = new System.Drawing.Point(231, 294);
            this.btnF.Name = "btnF";
            this.btnF.Size = new System.Drawing.Size(37, 32);
            this.btnF.TabIndex = 5;
            this.btnF.Text = "F";
            this.btnF.UseVisualStyleBackColor = true;
            // 
            // btnG
            // 
            this.btnG.Location = new System.Drawing.Point(274, 294);
            this.btnG.Name = "btnG";
            this.btnG.Size = new System.Drawing.Size(37, 32);
            this.btnG.TabIndex = 6;
            this.btnG.Text = "G";
            this.btnG.UseVisualStyleBackColor = true;
            // 
            // btnH
            // 
            this.btnH.Location = new System.Drawing.Point(317, 294);
            this.btnH.Name = "btnH";
            this.btnH.Size = new System.Drawing.Size(37, 32);
            this.btnH.TabIndex = 7;
            this.btnH.Text = "H";
            this.btnH.UseVisualStyleBackColor = true;
            // 
            // btnI
            // 
            this.btnI.Location = new System.Drawing.Point(360, 294);
            this.btnI.Name = "btnI";
            this.btnI.Size = new System.Drawing.Size(37, 32);
            this.btnI.TabIndex = 8;
            this.btnI.Text = "I";
            this.btnI.UseVisualStyleBackColor = true;
            // 
            // btnJ
            // 
            this.btnJ.Location = new System.Drawing.Point(403, 294);
            this.btnJ.Name = "btnJ";
            this.btnJ.Size = new System.Drawing.Size(37, 32);
            this.btnJ.TabIndex = 9;
            this.btnJ.Text = "J";
            this.btnJ.UseVisualStyleBackColor = true;
            // 
            // btnK
            // 
            this.btnK.Location = new System.Drawing.Point(36, 332);
            this.btnK.Name = "btnK";
            this.btnK.Size = new System.Drawing.Size(37, 32);
            this.btnK.TabIndex = 10;
            this.btnK.Text = "K";
            this.btnK.UseVisualStyleBackColor = true;
            // 
            // btnL
            // 
            this.btnL.Location = new System.Drawing.Point(79, 332);
            this.btnL.Name = "btnL";
            this.btnL.Size = new System.Drawing.Size(37, 32);
            this.btnL.TabIndex = 11;
            this.btnL.Text = "L";
            this.btnL.UseVisualStyleBackColor = true;
            // 
            // btnM
            // 
            this.btnM.Location = new System.Drawing.Point(122, 332);
            this.btnM.Name = "btnM";
            this.btnM.Size = new System.Drawing.Size(37, 32);
            this.btnM.TabIndex = 12;
            this.btnM.Text = "M";
            this.btnM.UseVisualStyleBackColor = true;
            // 
            // btnN
            // 
            this.btnN.Location = new System.Drawing.Point(165, 332);
            this.btnN.Name = "btnN";
            this.btnN.Size = new System.Drawing.Size(37, 32);
            this.btnN.TabIndex = 13;
            this.btnN.Text = "N";
            this.btnN.UseVisualStyleBackColor = true;
            // 
            // btnR
            // 
            this.btnR.Location = new System.Drawing.Point(337, 332);
            this.btnR.Name = "btnR";
            this.btnR.Size = new System.Drawing.Size(37, 32);
            this.btnR.TabIndex = 14;
            this.btnR.Text = "R";
            this.btnR.UseVisualStyleBackColor = true;
            // 
            // btnQ
            // 
            this.btnQ.Location = new System.Drawing.Point(294, 332);
            this.btnQ.Name = "btnQ";
            this.btnQ.Size = new System.Drawing.Size(37, 32);
            this.btnQ.TabIndex = 15;
            this.btnQ.Text = "Q";
            this.btnQ.UseVisualStyleBackColor = true;
            // 
            // btnP
            // 
            this.btnP.Location = new System.Drawing.Point(251, 332);
            this.btnP.Name = "btnP";
            this.btnP.Size = new System.Drawing.Size(37, 32);
            this.btnP.TabIndex = 16;
            this.btnP.Text = "P";
            this.btnP.UseVisualStyleBackColor = true;
            // 
            // btnO
            // 
            this.btnO.Location = new System.Drawing.Point(208, 332);
            this.btnO.Name = "btnO";
            this.btnO.Size = new System.Drawing.Size(37, 32);
            this.btnO.TabIndex = 17;
            this.btnO.Text = "O";
            this.btnO.UseVisualStyleBackColor = true;
            // 
            // btnX
            // 
            this.btnX.Location = new System.Drawing.Point(251, 370);
            this.btnX.Name = "btnX";
            this.btnX.Size = new System.Drawing.Size(37, 32);
            this.btnX.TabIndex = 18;
            this.btnX.Text = "X";
            this.btnX.UseVisualStyleBackColor = true;
            // 
            // btnW
            // 
            this.btnW.Location = new System.Drawing.Point(208, 370);
            this.btnW.Name = "btnW";
            this.btnW.Size = new System.Drawing.Size(37, 32);
            this.btnW.TabIndex = 19;
            this.btnW.Text = "W";
            this.btnW.UseVisualStyleBackColor = true;
            // 
            // btnV
            // 
            this.btnV.Location = new System.Drawing.Point(165, 370);
            this.btnV.Name = "btnV";
            this.btnV.Size = new System.Drawing.Size(37, 32);
            this.btnV.TabIndex = 20;
            this.btnV.Text = "V";
            this.btnV.UseVisualStyleBackColor = true;
            // 
            // btnU
            // 
            this.btnU.Location = new System.Drawing.Point(122, 370);
            this.btnU.Name = "btnU";
            this.btnU.Size = new System.Drawing.Size(37, 32);
            this.btnU.TabIndex = 21;
            this.btnU.Text = "U";
            this.btnU.UseVisualStyleBackColor = true;
            // 
            // btnT
            // 
            this.btnT.Location = new System.Drawing.Point(79, 370);
            this.btnT.Name = "btnT";
            this.btnT.Size = new System.Drawing.Size(37, 32);
            this.btnT.TabIndex = 22;
            this.btnT.Text = "T";
            this.btnT.UseVisualStyleBackColor = true;
            // 
            // btnZ
            // 
            this.btnZ.Location = new System.Drawing.Point(337, 370);
            this.btnZ.Name = "btnZ";
            this.btnZ.Size = new System.Drawing.Size(37, 32);
            this.btnZ.TabIndex = 23;
            this.btnZ.Text = "Z";
            this.btnZ.UseVisualStyleBackColor = true;
            // 
            // btnY
            // 
            this.btnY.Location = new System.Drawing.Point(294, 370);
            this.btnY.Name = "btnY";
            this.btnY.Size = new System.Drawing.Size(37, 32);
            this.btnY.TabIndex = 24;
            this.btnY.Text = "Y";
            this.btnY.UseVisualStyleBackColor = true;
            // 
            // btnS
            // 
            this.btnS.Location = new System.Drawing.Point(380, 332);
            this.btnS.Name = "btnS";
            this.btnS.Size = new System.Drawing.Size(37, 32);
            this.btnS.TabIndex = 25;
            this.btnS.Text = "S";
            this.btnS.UseVisualStyleBackColor = true;
            // 
            // txtWord
            // 
            this.txtWord.Location = new System.Drawing.Point(16, 56);
            this.txtWord.Multiline = true;
            this.txtWord.Name = "txtWord";
            this.txtWord.Size = new System.Drawing.Size(248, 107);
            this.txtWord.TabIndex = 26;
            this.txtWord.TextChanged += new System.EventHandler(this.txtWord_TextChanged);
            // 
            // lblInput
            // 
            this.lblInput.AutoSize = true;
            this.lblInput.Font = new System.Drawing.Font("Goudy Old Style", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInput.Location = new System.Drawing.Point(31, 28);
            this.lblInput.Name = "lblInput";
            this.lblInput.Size = new System.Drawing.Size(233, 25);
            this.lblInput.TabIndex = 27;
            this.lblInput.Text = "Enter Word or Sentence :";
            // 
            // lblLetter
            // 
            this.lblLetter.AutoSize = true;
            this.lblLetter.Font = new System.Drawing.Font("Goudy Old Style", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLetter.Location = new System.Drawing.Point(153, 250);
            this.lblLetter.Name = "lblLetter";
            this.lblLetter.Size = new System.Drawing.Size(115, 25);
            this.lblLetter.TabIndex = 28;
            this.lblLetter.Text = "Click Letter";
            // 
            // txtOut
            // 
            this.txtOut.Location = new System.Drawing.Point(294, 56);
            this.txtOut.Multiline = true;
            this.txtOut.Name = "txtOut";
            this.txtOut.Size = new System.Drawing.Size(248, 107);
            this.txtOut.TabIndex = 26;
            // 
            // btnEncrypt
            // 
            this.btnEncrypt.Font = new System.Drawing.Font("Goudy Old Style", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEncrypt.ForeColor = System.Drawing.Color.Black;
            this.btnEncrypt.Location = new System.Drawing.Point(78, 169);
            this.btnEncrypt.Name = "btnEncrypt";
            this.btnEncrypt.Size = new System.Drawing.Size(104, 41);
            this.btnEncrypt.TabIndex = 29;
            this.btnEncrypt.Text = "Encrypt";
            this.btnEncrypt.UseVisualStyleBackColor = true;
            this.btnEncrypt.Click += new System.EventHandler(this.btnEncrypt_Click);
            // 
            // lblOutput
            // 
            this.lblOutput.AutoSize = true;
            this.lblOutput.Font = new System.Drawing.Font("Goudy Old Style", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOutput.Location = new System.Drawing.Point(348, 28);
            this.lblOutput.Name = "lblOutput";
            this.lblOutput.Size = new System.Drawing.Size(103, 25);
            this.lblOutput.TabIndex = 30;
            this.lblOutput.Text = "Decipher :";
            // 
            // txtSolve
            // 
            this.txtSolve.Location = new System.Drawing.Point(16, 489);
            this.txtSolve.Multiline = true;
            this.txtSolve.Name = "txtSolve";
            this.txtSolve.Size = new System.Drawing.Size(248, 107);
            this.txtSolve.TabIndex = 31;
            // 
            // lblSolve
            // 
            this.lblSolve.AutoSize = true;
            this.lblSolve.Font = new System.Drawing.Font("Goudy Old Style", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSolve.Location = new System.Drawing.Point(45, 461);
            this.lblSolve.Name = "lblSolve";
            this.lblSolve.Size = new System.Drawing.Size(168, 25);
            this.lblSolve.TabIndex = 32;
            this.lblSolve.Text = "Attempt to Solve :";
            // 
            // Hangman
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(868, 627);
            this.Controls.Add(this.lblSolve);
            this.Controls.Add(this.txtSolve);
            this.Controls.Add(this.lblOutput);
            this.Controls.Add(this.btnEncrypt);
            this.Controls.Add(this.txtOut);
            this.Controls.Add(this.lblLetter);
            this.Controls.Add(this.lblInput);
            this.Controls.Add(this.txtWord);
            this.Controls.Add(this.btnS);
            this.Controls.Add(this.btnY);
            this.Controls.Add(this.btnZ);
            this.Controls.Add(this.btnT);
            this.Controls.Add(this.btnU);
            this.Controls.Add(this.btnV);
            this.Controls.Add(this.btnW);
            this.Controls.Add(this.btnX);
            this.Controls.Add(this.btnO);
            this.Controls.Add(this.btnP);
            this.Controls.Add(this.btnQ);
            this.Controls.Add(this.btnR);
            this.Controls.Add(this.btnN);
            this.Controls.Add(this.btnM);
            this.Controls.Add(this.btnL);
            this.Controls.Add(this.btnK);
            this.Controls.Add(this.btnJ);
            this.Controls.Add(this.btnI);
            this.Controls.Add(this.btnH);
            this.Controls.Add(this.btnG);
            this.Controls.Add(this.btnF);
            this.Controls.Add(this.btnE);
            this.Controls.Add(this.btnD);
            this.Controls.Add(this.btnC);
            this.Controls.Add(this.btnB);
            this.Controls.Add(this.btnA);
            this.Name = "Hangman";
            this.Text = "Hangman";
            this.Load += new System.EventHandler(this.Hangman_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnA;
        private System.Windows.Forms.Button btnB;
        private System.Windows.Forms.Button btnC;
        private System.Windows.Forms.Button btnD;
        private System.Windows.Forms.Button btnE;
        private System.Windows.Forms.Button btnF;
        private System.Windows.Forms.Button btnG;
        private System.Windows.Forms.Button btnH;
        private System.Windows.Forms.Button btnI;
        private System.Windows.Forms.Button btnJ;
        private System.Windows.Forms.Button btnK;
        private System.Windows.Forms.Button btnL;
        private System.Windows.Forms.Button btnM;
        private System.Windows.Forms.Button btnN;
        private System.Windows.Forms.Button btnR;
        private System.Windows.Forms.Button btnQ;
        private System.Windows.Forms.Button btnP;
        private System.Windows.Forms.Button btnO;
        private System.Windows.Forms.Button btnX;
        private System.Windows.Forms.Button btnW;
        private System.Windows.Forms.Button btnV;
        private System.Windows.Forms.Button btnU;
        private System.Windows.Forms.Button btnT;
        private System.Windows.Forms.Button btnZ;
        private System.Windows.Forms.Button btnY;
        private System.Windows.Forms.Button btnS;
        private System.Windows.Forms.TextBox txtWord;
        private System.Windows.Forms.Label lblInput;
        private System.Windows.Forms.Label lblLetter;
        private System.Windows.Forms.TextBox txtOut;
        private System.Windows.Forms.Button btnEncrypt;
        private System.Windows.Forms.Label lblOutput;
        private System.Windows.Forms.TextBox txtSolve;
        private System.Windows.Forms.Label lblSolve;
    }
}

