﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hangman
{
    public partial class Hangman : Form
    {
        String scram;
        List<char> z = new List<char>();

        public Hangman()
        {
            InitializeComponent();
        }

        private void Hangman_Load(object sender, EventArgs e)
        {
            this.Text = "Hangman";
        }

        private void txtWord_TextChanged(object sender, EventArgs e)
        {



        }

        private void btnEncrypt_Click(object sender, EventArgs e)
        {
            scram = txtWord.Text;

            int Encrypt = scram.Length -1;
            int add = 0;

            while (Encrypt >= add)
            {
                if (scram[add] != ' ')
                {
                    z.Add('-');
                }
                else
                {
                    z.Add(' ');
                }
                add++;
            }
            txtOut.Text = String.Join("", z.ToArray());
        }
    }
}