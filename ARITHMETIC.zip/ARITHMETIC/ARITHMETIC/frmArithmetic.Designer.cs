﻿namespace ARITHMETIC
{
    partial class frmArithmetic
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnSubtract = new System.Windows.Forms.Button();
            this.btnMultiply = new System.Windows.Forms.Button();
            this.btnMax = new System.Windows.Forms.Button();
            this.btnRandom = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.txtIn1 = new System.Windows.Forms.TextBox();
            this.txtIn2 = new System.Windows.Forms.TextBox();
            this.lstOut = new System.Windows.Forms.ListBox();
            this.picMath = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picMath)).BeginInit();
            this.SuspendLayout();
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.Lime;
            this.btnAdd.Location = new System.Drawing.Point(46, 47);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(133, 28);
            this.btnAdd.TabIndex = 0;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // btnSubtract
            // 
            this.btnSubtract.BackColor = System.Drawing.Color.Lime;
            this.btnSubtract.Location = new System.Drawing.Point(46, 81);
            this.btnSubtract.Name = "btnSubtract";
            this.btnSubtract.Size = new System.Drawing.Size(133, 30);
            this.btnSubtract.TabIndex = 1;
            this.btnSubtract.Text = "Subtract";
            this.btnSubtract.UseVisualStyleBackColor = false;
            this.btnSubtract.Click += new System.EventHandler(this.btnSubtract_Click);
            // 
            // btnMultiply
            // 
            this.btnMultiply.BackColor = System.Drawing.Color.Lime;
            this.btnMultiply.Location = new System.Drawing.Point(46, 117);
            this.btnMultiply.Name = "btnMultiply";
            this.btnMultiply.Size = new System.Drawing.Size(133, 35);
            this.btnMultiply.TabIndex = 2;
            this.btnMultiply.Text = "Multiply";
            this.btnMultiply.UseVisualStyleBackColor = false;
            this.btnMultiply.Click += new System.EventHandler(this.btnMultiply_Click);
            // 
            // btnMax
            // 
            this.btnMax.BackColor = System.Drawing.Color.Turquoise;
            this.btnMax.Location = new System.Drawing.Point(46, 158);
            this.btnMax.Name = "btnMax";
            this.btnMax.Size = new System.Drawing.Size(133, 32);
            this.btnMax.TabIndex = 3;
            this.btnMax.Text = "Bigger";
            this.btnMax.UseVisualStyleBackColor = false;
            this.btnMax.Click += new System.EventHandler(this.btnMax_Click);
            // 
            // btnRandom
            // 
            this.btnRandom.BackColor = System.Drawing.Color.Turquoise;
            this.btnRandom.Location = new System.Drawing.Point(48, 196);
            this.btnRandom.Name = "btnRandom";
            this.btnRandom.Size = new System.Drawing.Size(131, 31);
            this.btnRandom.TabIndex = 4;
            this.btnRandom.Text = "Random #s";
            this.btnRandom.UseVisualStyleBackColor = false;
            this.btnRandom.Click += new System.EventHandler(this.btnRandom_Click);
            // 
            // btnClear
            // 
            this.btnClear.BackColor = System.Drawing.Color.Red;
            this.btnClear.Location = new System.Drawing.Point(46, 233);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(133, 32);
            this.btnClear.TabIndex = 5;
            this.btnClear.Text = "Clear All";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // txtIn1
            // 
            this.txtIn1.Location = new System.Drawing.Point(202, 52);
            this.txtIn1.Name = "txtIn1";
            this.txtIn1.Size = new System.Drawing.Size(106, 20);
            this.txtIn1.TabIndex = 6;
            // 
            // txtIn2
            // 
            this.txtIn2.Location = new System.Drawing.Point(202, 87);
            this.txtIn2.Name = "txtIn2";
            this.txtIn2.Size = new System.Drawing.Size(106, 20);
            this.txtIn2.TabIndex = 7;
            // 
            // lstOut
            // 
            this.lstOut.BackColor = System.Drawing.Color.Black;
            this.lstOut.Font = new System.Drawing.Font("Consolas", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstOut.ForeColor = System.Drawing.Color.Silver;
            this.lstOut.FormattingEnabled = true;
            this.lstOut.ItemHeight = 14;
            this.lstOut.Location = new System.Drawing.Point(328, 47);
            this.lstOut.Name = "lstOut";
            this.lstOut.Size = new System.Drawing.Size(318, 410);
            this.lstOut.TabIndex = 8;
            // 
            // picMath
            // 
            this.picMath.Image = global::ARITHMETIC.Properties.Resources.th;
            this.picMath.Location = new System.Drawing.Point(58, 315);
            this.picMath.Name = "picMath";
            this.picMath.Size = new System.Drawing.Size(208, 144);
            this.picMath.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picMath.TabIndex = 9;
            this.picMath.TabStop = false;
            this.picMath.Click += new System.EventHandler(this.picMath_Click);
            // 
            // frmArithmetic
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(658, 477);
            this.Controls.Add(this.picMath);
            this.Controls.Add(this.lstOut);
            this.Controls.Add(this.txtIn2);
            this.Controls.Add(this.txtIn1);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnRandom);
            this.Controls.Add(this.btnMax);
            this.Controls.Add(this.btnMultiply);
            this.Controls.Add(this.btnSubtract);
            this.Controls.Add(this.btnAdd);
            this.Name = "frmArithmetic";
            this.Text = "burch ARITHMETIC";
            ((System.ComponentModel.ISupportInitialize)(this.picMath)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnSubtract;
        private System.Windows.Forms.Button btnMultiply;
        private System.Windows.Forms.Button btnMax;
        private System.Windows.Forms.Button btnRandom;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.TextBox txtIn1;
        private System.Windows.Forms.TextBox txtIn2;
        private System.Windows.Forms.ListBox lstOut;
        private System.Windows.Forms.PictureBox picMath;
    }
}

