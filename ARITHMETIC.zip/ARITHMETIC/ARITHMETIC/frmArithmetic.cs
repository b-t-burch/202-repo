﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ARITHMETIC
{
    public partial class frmArithmetic : Form
    {
        public frmArithmetic()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                int var1 = int.Parse(txtIn1.Text);
                int var2 = int.Parse(txtIn2.Text);
                int Addvars = var1 + var2;
                lstOut.Items.Add( var1 + " + " + var2 + " = " + Addvars );
                

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btnSubtract_Click(object sender, EventArgs e)
        {
            try
            {
                int var1 = int.Parse(txtIn1.Text);
                int var2 = int.Parse(txtIn2.Text);
                int Subtractvars = var1 - var2;
                lstOut.Items.Add( var1 + " - " + var2 + " = " + Subtractvars );
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnMultiply_Click(object sender, EventArgs e)
        {
            try
            {
                int var1 = int.Parse(txtIn1.Text);
                int var2 = int.Parse(txtIn2.Text);
                int Multiplyvars = var1 * var2;
                lstOut.Items.Add(var1 + " * " + var2 + " = " + Multiplyvars);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnMax_Click(object sender, EventArgs e)
        {
            try
            {
                int var1 = int.Parse(txtIn1.Text);
                int var2 = int.Parse(txtIn2.Text);
                int Maxvars = Math.Max(var1,var2);
                lstOut.Items.Add("The bigger of " + var1 + " and " + var2 + " is " + Maxvars);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnRandom_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();

            int num = rnd.Next(1, 101);
            int num1 = rnd.Next(1, 101);
            int num2 = rnd.Next(1, 101);

            txtIn1.Text = num1.ToString();
            txtIn2.Text = num2.ToString();
                
            

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtIn1.Clear();
            txtIn2.Clear();
            lstOut.Items.Clear();
            txtIn1.Focus();
            picMath.Show();

        }

        private void picMath_Click(object sender, EventArgs e)
        {
            picMath.Hide();
        }
    }
}
