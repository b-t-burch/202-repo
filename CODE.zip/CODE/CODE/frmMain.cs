﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


// Burch
//CIS 202 - CODE
//
//Enter text into two textboxes
//When button is pressed join strings
//and display two strings from two textboxes and the joined string





namespace CODE
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Text = "Brendan Burch";
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtOut.Clear();
            txtIn1.Clear();
            txtIn2.Clear();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnJoin_Click(object sender, EventArgs e)
        {
            string str1 = txtIn1.Text;
            string str2 = txtIn2.Text;
            string strOut = str1 + str2;
            txtOut.Text = str1 + " + " + str2 + " = " + strOut;
           
        }
    }
}
