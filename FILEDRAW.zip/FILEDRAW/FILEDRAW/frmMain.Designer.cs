﻿namespace FILEDRAW
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnFileProcess = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.panDraw = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // btnFileProcess
            // 
            this.btnFileProcess.Location = new System.Drawing.Point(130, 514);
            this.btnFileProcess.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnFileProcess.Name = "btnFileProcess";
            this.btnFileProcess.Size = new System.Drawing.Size(157, 76);
            this.btnFileProcess.TabIndex = 0;
            this.btnFileProcess.Text = "Read File and Create Image";
            this.btnFileProcess.UseVisualStyleBackColor = true;
            this.btnFileProcess.Click += new System.EventHandler(this.btnFileProcess_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(385, 514);
            this.btnClear.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(157, 76);
            this.btnClear.TabIndex = 1;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // panDraw
            // 
            this.panDraw.Location = new System.Drawing.Point(74, 10);
            this.panDraw.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.panDraw.Name = "panDraw";
            this.panDraw.Size = new System.Drawing.Size(500, 500);
            this.panDraw.TabIndex = 0;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(700, 635);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.panDraw);
            this.Controls.Add(this.btnFileProcess);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "frmMain";
            this.Text = "Burch DrawWithFiles";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnFileProcess;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Panel panDraw;
    }
}

