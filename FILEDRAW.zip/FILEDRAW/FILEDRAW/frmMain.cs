﻿using System;
using System.Windows.Forms;
using System.Drawing;
using System.IO;


namespace FILEDRAW
{
    public partial class frmMain : Form
    {
        Graphics gr; // variable for graphics system//
        Brush br = new SolidBrush(Color.White); // variable for brush, sets default brush color //
        StreamReader reader; // creates file reader // 
        int Rect = 0; 
        int Ellip = 0;  // starting values for stats //
        int Col = 0;


        public frmMain()
        {
            InitializeComponent();
        }


        private void btnFileProcess_Click(object sender, EventArgs e) // Event handler for read file button //
        {
            try
            {
                reader = File.OpenText("DRAW.txt"); // Reads embeded file // 
                while (reader.EndOfStream == false)
                {
                    string REC = reader.ReadLine();  // R E C = rectangle, ellipses, Color from data file //
                    int Num1 = int.Parse(reader.ReadLine()); // variables used while reading draw.txt//
                    int Num2 = int.Parse(reader.ReadLine());
                    int Num3 = int.Parse(reader.ReadLine());
                    int Num4 = int.Parse(reader.ReadLine());

                    if (REC == "R")
                    {
                        Rectangle(Num1, Num2, Num3, Num4);
                        Rect++;
                    }
                    else if (REC == "E")
                    {
                        Ellipse(Num1, Num2, Num3, Num4);
                        Ellip++;
                    }
                    else if (REC == "C")
                    {
                        Colors(Num1, Num2, Num3, Num4);
                        Col++;
                    }
                    else
                    {
                        MessageBox.Show("Improper file format");
                    }

                }
                Stats(); // calls stats function //
                reader.Close(); // closes the file //
            }
            catch (Exception)
            {
                MessageBox.Show("Improper file format");
            }
        }

        private void btnClear_Click(object sender, EventArgs e) // clears image, defaults panel to white, clears label values //
        {
            gr.Clear(Color.White);
            
        }

        private void frmMain_Load(object sender, EventArgs e) // generates graphics object on form load //
        {
            gr = panDraw.CreateGraphics();
            panDraw.Focus();
            
        }

        private void Rectangle(int x, int y, int w, int h) // creates rectangle values //
        {
            gr.FillRectangle(br, x, y, w, h);
        }

        private void Ellipse(int x, int y, int w, int h) // creates ellipses values //
        {
            gr.FillEllipse(br, x, y, w, h);
        }

        private void Colors(int a, int r, int g, int b) // creates color values //
        {
            br = new SolidBrush(Color.FromArgb(a, r, g, b));
        }

        private void Stats() // displays stats for current image // 
        {
            Font myFont = new Font("Consolas", 14);
            gr.DrawString("Rectangle: " + Rect.ToString(), myFont, Brushes.Blue, 10, 350);
            gr.DrawString("Ellipse: " + Ellip.ToString(), myFont, Brushes.Blue, 10, 380);
            gr.DrawString("Rectangle: " + Col.ToString(), myFont, Brushes.Blue, 10, 410);

        }
    }
}
