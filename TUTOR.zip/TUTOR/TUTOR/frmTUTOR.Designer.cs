﻿namespace TUTOR
{
    partial class frmTUTOR
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.radAddition = new System.Windows.Forms.RadioButton();
            this.radSubtraction = new System.Windows.Forms.RadioButton();
            this.radMultiply = new System.Windows.Forms.RadioButton();
            this.grpOperation = new System.Windows.Forms.GroupBox();
            this.chkTimer = new System.Windows.Forms.CheckBox();
            this.lblTimer = new System.Windows.Forms.Label();
            this.btnReset = new System.Windows.Forms.Button();
            this.grpTime = new System.Windows.Forms.GroupBox();
            this.txtNum1 = new System.Windows.Forms.TextBox();
            this.txtNum2 = new System.Windows.Forms.TextBox();
            this.txtAnswer = new System.Windows.Forms.TextBox();
            this.txtOperation = new System.Windows.Forms.TextBox();
            this.txtEquals = new System.Windows.Forms.TextBox();
            this.grpRange = new System.Windows.Forms.GroupBox();
            this.radLarge = new System.Windows.Forms.RadioButton();
            this.radSmall = new System.Windows.Forms.RadioButton();
            this.btnNewprob = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblProbs = new System.Windows.Forms.Label();
            this.lblPercent = new System.Windows.Forms.Label();
            this.lblCorrect = new System.Windows.Forms.Label();
            this.lblIncorrect = new System.Windows.Forms.Label();
            this.grpStats = new System.Windows.Forms.GroupBox();
            this.picWrong = new System.Windows.Forms.PictureBox();
            this.picRight = new System.Windows.Forms.PictureBox();
            this.Timer = new System.Windows.Forms.Timer(this.components);
            this.btnAnswer = new System.Windows.Forms.Button();
            this.grpOperation.SuspendLayout();
            this.grpTime.SuspendLayout();
            this.grpRange.SuspendLayout();
            this.grpStats.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picWrong)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRight)).BeginInit();
            this.SuspendLayout();
            // 
            // radAddition
            // 
            this.radAddition.AutoSize = true;
            this.radAddition.Checked = true;
            this.radAddition.Location = new System.Drawing.Point(52, 39);
            this.radAddition.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.radAddition.Name = "radAddition";
            this.radAddition.Size = new System.Drawing.Size(80, 21);
            this.radAddition.TabIndex = 0;
            this.radAddition.TabStop = true;
            this.radAddition.Text = "Addition";
            this.radAddition.UseVisualStyleBackColor = true;
            // 
            // radSubtraction
            // 
            this.radSubtraction.AutoSize = true;
            this.radSubtraction.Location = new System.Drawing.Point(52, 90);
            this.radSubtraction.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.radSubtraction.Name = "radSubtraction";
            this.radSubtraction.Size = new System.Drawing.Size(101, 21);
            this.radSubtraction.TabIndex = 1;
            this.radSubtraction.TabStop = true;
            this.radSubtraction.Text = "Subtraction";
            this.radSubtraction.UseVisualStyleBackColor = true;
            // 
            // radMultiply
            // 
            this.radMultiply.AutoSize = true;
            this.radMultiply.Location = new System.Drawing.Point(52, 138);
            this.radMultiply.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.radMultiply.Name = "radMultiply";
            this.radMultiply.Size = new System.Drawing.Size(110, 21);
            this.radMultiply.TabIndex = 2;
            this.radMultiply.TabStop = true;
            this.radMultiply.Text = "Multiplication";
            this.radMultiply.UseVisualStyleBackColor = true;
            // 
            // grpOperation
            // 
            this.grpOperation.Controls.Add(this.radMultiply);
            this.grpOperation.Controls.Add(this.radSubtraction);
            this.grpOperation.Controls.Add(this.radAddition);
            this.grpOperation.Location = new System.Drawing.Point(9, 2);
            this.grpOperation.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.grpOperation.Name = "grpOperation";
            this.grpOperation.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.grpOperation.Size = new System.Drawing.Size(252, 202);
            this.grpOperation.TabIndex = 3;
            this.grpOperation.TabStop = false;
            this.grpOperation.Text = "Operations";
            // 
            // chkTimer
            // 
            this.chkTimer.AutoSize = true;
            this.chkTimer.Location = new System.Drawing.Point(75, 21);
            this.chkTimer.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkTimer.Name = "chkTimer";
            this.chkTimer.Size = new System.Drawing.Size(72, 21);
            this.chkTimer.TabIndex = 4;
            this.chkTimer.Text = "On/Off";
            this.chkTimer.UseVisualStyleBackColor = true;
            // 
            // lblTimer
            // 
            this.lblTimer.AutoSize = true;
            this.lblTimer.Location = new System.Drawing.Point(27, 49);
            this.lblTimer.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTimer.Name = "lblTimer";
            this.lblTimer.Size = new System.Drawing.Size(16, 17);
            this.lblTimer.TabIndex = 5;
            this.lblTimer.Text = "0";
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(76, 58);
            this.btnReset.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(81, 38);
            this.btnReset.TabIndex = 6;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // grpTime
            // 
            this.grpTime.Controls.Add(this.btnReset);
            this.grpTime.Controls.Add(this.chkTimer);
            this.grpTime.Controls.Add(this.lblTimer);
            this.grpTime.Location = new System.Drawing.Point(92, 384);
            this.grpTime.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.grpTime.Name = "grpTime";
            this.grpTime.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.grpTime.Size = new System.Drawing.Size(189, 103);
            this.grpTime.TabIndex = 7;
            this.grpTime.TabStop = false;
            this.grpTime.Text = "Timer";
            // 
            // txtNum1
            // 
            this.txtNum1.Location = new System.Drawing.Point(9, 315);
            this.txtNum1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtNum1.Name = "txtNum1";
            this.txtNum1.ReadOnly = true;
            this.txtNum1.Size = new System.Drawing.Size(73, 22);
            this.txtNum1.TabIndex = 8;
            // 
            // txtNum2
            // 
            this.txtNum2.Location = new System.Drawing.Point(140, 315);
            this.txtNum2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtNum2.Name = "txtNum2";
            this.txtNum2.ReadOnly = true;
            this.txtNum2.Size = new System.Drawing.Size(73, 22);
            this.txtNum2.TabIndex = 9;
            // 
            // txtAnswer
            // 
            this.txtAnswer.Location = new System.Drawing.Point(271, 315);
            this.txtAnswer.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtAnswer.Name = "txtAnswer";
            this.txtAnswer.Size = new System.Drawing.Size(73, 22);
            this.txtAnswer.TabIndex = 10;
            // 
            // txtOperation
            // 
            this.txtOperation.Location = new System.Drawing.Point(92, 315);
            this.txtOperation.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtOperation.Name = "txtOperation";
            this.txtOperation.ReadOnly = true;
            this.txtOperation.Size = new System.Drawing.Size(39, 22);
            this.txtOperation.TabIndex = 11;
            // 
            // txtEquals
            // 
            this.txtEquals.Location = new System.Drawing.Point(223, 315);
            this.txtEquals.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtEquals.Name = "txtEquals";
            this.txtEquals.ReadOnly = true;
            this.txtEquals.Size = new System.Drawing.Size(39, 22);
            this.txtEquals.TabIndex = 12;
            this.txtEquals.Text = " =";
            // 
            // grpRange
            // 
            this.grpRange.Controls.Add(this.radLarge);
            this.grpRange.Controls.Add(this.radSmall);
            this.grpRange.Location = new System.Drawing.Point(509, 241);
            this.grpRange.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.grpRange.Name = "grpRange";
            this.grpRange.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.grpRange.Size = new System.Drawing.Size(153, 98);
            this.grpRange.TabIndex = 18;
            this.grpRange.TabStop = false;
            this.grpRange.Text = "Number Range";
            // 
            // radLarge
            // 
            this.radLarge.AutoSize = true;
            this.radLarge.Location = new System.Drawing.Point(8, 58);
            this.radLarge.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.radLarge.Name = "radLarge";
            this.radLarge.Size = new System.Drawing.Size(66, 21);
            this.radLarge.TabIndex = 1;
            this.radLarge.Text = "1 - 24";
            this.radLarge.UseVisualStyleBackColor = true;
            // 
            // radSmall
            // 
            this.radSmall.AutoSize = true;
            this.radSmall.Checked = true;
            this.radSmall.Location = new System.Drawing.Point(8, 30);
            this.radSmall.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.radSmall.Name = "radSmall";
            this.radSmall.Size = new System.Drawing.Size(66, 21);
            this.radSmall.TabIndex = 0;
            this.radSmall.TabStop = true;
            this.radSmall.Text = "1 - 12";
            this.radSmall.UseVisualStyleBackColor = true;
            // 
            // btnNewprob
            // 
            this.btnNewprob.Location = new System.Drawing.Point(88, 234);
            this.btnNewprob.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnNewprob.Name = "btnNewprob";
            this.btnNewprob.Size = new System.Drawing.Size(173, 58);
            this.btnNewprob.TabIndex = 19;
            this.btnNewprob.Text = "Get New Problem";
            this.btnNewprob.UseVisualStyleBackColor = true;
            this.btnNewprob.Click += new System.EventHandler(this.btnNewprob_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(16, 495);
            this.btnClear.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(173, 58);
            this.btnClear.TabIndex = 20;
            this.btnClear.Text = "Clear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(223, 495);
            this.btnExit.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(173, 58);
            this.btnExit.TabIndex = 21;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblProbs
            // 
            this.lblProbs.AutoSize = true;
            this.lblProbs.Location = new System.Drawing.Point(20, 36);
            this.lblProbs.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblProbs.Name = "lblProbs";
            this.lblProbs.Size = new System.Drawing.Size(71, 17);
            this.lblProbs.TabIndex = 22;
            this.lblProbs.Text = "Problems:";
            // 
            // lblPercent
            // 
            this.lblPercent.AutoSize = true;
            this.lblPercent.Location = new System.Drawing.Point(20, 68);
            this.lblPercent.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPercent.Name = "lblPercent";
            this.lblPercent.Size = new System.Drawing.Size(111, 17);
            this.lblPercent.TabIndex = 23;
            this.lblPercent.Text = "Percent Correct:";
            // 
            // lblCorrect
            // 
            this.lblCorrect.AutoSize = true;
            this.lblCorrect.Location = new System.Drawing.Point(20, 116);
            this.lblCorrect.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCorrect.Name = "lblCorrect";
            this.lblCorrect.Size = new System.Drawing.Size(58, 17);
            this.lblCorrect.TabIndex = 24;
            this.lblCorrect.Text = "Correct:";
            // 
            // lblIncorrect
            // 
            this.lblIncorrect.AutoSize = true;
            this.lblIncorrect.Location = new System.Drawing.Point(107, 116);
            this.lblIncorrect.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblIncorrect.Name = "lblIncorrect";
            this.lblIncorrect.Size = new System.Drawing.Size(67, 17);
            this.lblIncorrect.TabIndex = 25;
            this.lblIncorrect.Text = "Incorrect:";
            // 
            // grpStats
            // 
            this.grpStats.Controls.Add(this.lblIncorrect);
            this.grpStats.Controls.Add(this.lblCorrect);
            this.grpStats.Controls.Add(this.lblPercent);
            this.grpStats.Controls.Add(this.lblProbs);
            this.grpStats.Location = new System.Drawing.Point(487, 30);
            this.grpStats.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.grpStats.Name = "grpStats";
            this.grpStats.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.grpStats.Size = new System.Drawing.Size(216, 151);
            this.grpStats.TabIndex = 26;
            this.grpStats.TabStop = false;
            this.grpStats.Text = "Statistics";
            // 
            // picWrong
            // 
            this.picWrong.Image = global::TUTOR.Properties.Resources._12065738771352376078Arnoud999_Right_or_wrong_5_svg_hi;
            this.picWrong.Location = new System.Drawing.Point(384, 197);
            this.picWrong.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.picWrong.Name = "picWrong";
            this.picWrong.Size = new System.Drawing.Size(100, 94);
            this.picWrong.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picWrong.TabIndex = 28;
            this.picWrong.TabStop = false;
            // 
            // picRight
            // 
            this.picRight.Image = global::TUTOR.Properties.Resources.th;
            this.picRight.Location = new System.Drawing.Point(271, 197);
            this.picRight.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.picRight.Name = "picRight";
            this.picRight.Size = new System.Drawing.Size(105, 95);
            this.picRight.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picRight.TabIndex = 27;
            this.picRight.TabStop = false;
            // 
            // Timer
            // 
            this.Timer.Enabled = true;
            this.Timer.Interval = 1000;
            this.Timer.Tick += new System.EventHandler(this.Timer_Tick);
            // 
            // btnAnswer
            // 
            this.btnAnswer.Location = new System.Drawing.Point(361, 314);
            this.btnAnswer.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnAnswer.Name = "btnAnswer";
            this.btnAnswer.Size = new System.Drawing.Size(125, 25);
            this.btnAnswer.TabIndex = 29;
            this.btnAnswer.Text = "Check Answer";
            this.btnAnswer.UseVisualStyleBackColor = true;
            this.btnAnswer.Click += new System.EventHandler(this.btnAnswer_Click);
            // 
            // frmTUTOR
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(803, 608);
            this.Controls.Add(this.btnAnswer);
            this.Controls.Add(this.picWrong);
            this.Controls.Add(this.picRight);
            this.Controls.Add(this.grpStats);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnNewprob);
            this.Controls.Add(this.grpRange);
            this.Controls.Add(this.txtEquals);
            this.Controls.Add(this.txtOperation);
            this.Controls.Add(this.txtAnswer);
            this.Controls.Add(this.txtNum2);
            this.Controls.Add(this.txtNum1);
            this.Controls.Add(this.grpTime);
            this.Controls.Add(this.grpOperation);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmTUTOR";
            this.Text = "Burch - Math";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.grpOperation.ResumeLayout(false);
            this.grpOperation.PerformLayout();
            this.grpTime.ResumeLayout(false);
            this.grpTime.PerformLayout();
            this.grpRange.ResumeLayout(false);
            this.grpRange.PerformLayout();
            this.grpStats.ResumeLayout(false);
            this.grpStats.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picWrong)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picRight)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton radAddition;
        private System.Windows.Forms.RadioButton radSubtraction;
        private System.Windows.Forms.RadioButton radMultiply;
        private System.Windows.Forms.GroupBox grpOperation;
        private System.Windows.Forms.CheckBox chkTimer;
        private System.Windows.Forms.Label lblTimer;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.GroupBox grpTime;
        private System.Windows.Forms.TextBox txtNum1;
        private System.Windows.Forms.TextBox txtNum2;
        private System.Windows.Forms.TextBox txtAnswer;
        private System.Windows.Forms.TextBox txtOperation;
        private System.Windows.Forms.TextBox txtEquals;
        private System.Windows.Forms.GroupBox grpRange;
        private System.Windows.Forms.Button btnNewprob;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblProbs;
        private System.Windows.Forms.Label lblPercent;
        private System.Windows.Forms.Label lblCorrect;
        private System.Windows.Forms.Label lblIncorrect;
        private System.Windows.Forms.GroupBox grpStats;
        private System.Windows.Forms.PictureBox picRight;
        private System.Windows.Forms.PictureBox picWrong;
        private System.Windows.Forms.Timer Timer;
        private System.Windows.Forms.Button btnAnswer;
        private System.Windows.Forms.RadioButton radLarge;
        private System.Windows.Forms.RadioButton radSmall;
    }
}

