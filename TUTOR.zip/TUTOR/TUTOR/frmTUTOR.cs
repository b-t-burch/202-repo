﻿using System;
using System.Windows.Forms;

namespace TUTOR
{
    public partial class frmTUTOR : Form
    {
        public frmTUTOR()
        {
            InitializeComponent();
        }

        // Scope level variables //
        int maxRange = 25;
        int answer;
        double problem;
        double incorrect;
        double correct;
        int sec = 0;
        int num1;
        int num2;

        private void btnNewprob_Click(object sender, EventArgs e)// Generates a new problem //
        {
            NumberRange(); // calls the number range for selected range value //
            Random rand = new Random(); // creates random number generator assigned to rand //

            num1 = rand.Next(0, maxRange); // assigns the random number value to num1 and num 2 //
            num2 = rand.Next(0, maxRange);

            txtNum1.Text = num1.ToString(); // inserts the random value into appropriate text box//
            txtNum2.Text = num2.ToString();

            if (radAddition.Checked == true) // creates mathmatical problem based on selected operation//
            {
                txtOperation.Text = " + ";
                answer = (num1 + num2);
            }
            else if (radSubtraction.Checked == true)
            {
                txtOperation.Text = " - ";
                answer = (num1 - num2);
            }
            else if (radMultiply.Checked == true)
            {
                txtOperation.Text = " x ";
                answer = (num1 * num2);
            }
        }  

            private void btnAnswer_Click(object sender, EventArgs e)// Generates the correct answer based on the operation //
            {
            try
            {
                int answer1 = int.Parse(txtAnswer.Text); // checks, shows picture, and adds result of "answer" to statistics based on correct or incorrect outcome //
                if (answer1 == answer)
                {
                    problem++;
                    correct++;
                    picWrong.Hide();
                    picRight.Show();
                    MessageBox.Show(" GOOD JOB!!!");
                    Statistics();
                }
                else
                {
                    problem++;
                    incorrect++;
                    picRight.Hide();
                    picWrong.Show();
                    MessageBox.Show("Sorry, the correct answer is: " + answer);
                    Statistics();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Form1_Load(object sender, EventArgs e)// Event when the form is loaded //
        {
            picRight.Hide(); // hides both pictures upon execution of program //
            picWrong.Hide();
        }

        private void btnClear_Click(object sender, EventArgs e)// Button for clearing all textboxes,
        {
            txtNum1.Clear();  // clears all text boxes and hides all pictures //
            txtNum2.Clear();
            txtAnswer.Clear();
            picRight.Hide();
            picWrong.Hide();
        }


        private void Timer_Tick(object sender, EventArgs e)//Method in regards to functionality of the timer//
        {
            if (chkTimer.Checked == true) // When timer is checked - timer starts//
            {
                sec++; 
                lblTimer.Text = sec.ToString();
            }
            else if (chkTimer.Checked != true) // Timer is not checked - time displayed as 0 //
            {
                sec = 0;
                lblTimer.Text = "0";
            }
        }

        private void btnReset_Click(object sender, EventArgs e) // continues running timer - resets time to 0 // 
        {
            sec = 0;
            lblTimer.Text = " 0 ";
        }

        private void btnExit_Click(object sender, EventArgs e) // verifies that the program should be closed //
        {
            DialogResult result;
            result = MessageBox.Show(" Are you sure you wish to exit?", //nessage//
                                        "Exiting!", //caption
                                        MessageBoxButtons.YesNo); //buttons//
            if (result == DialogResult.Yes)
            this.Close();
        }

        private void Statistics()
        {
            lblIncorrect.Text = ("Incorrect : " + incorrect); // increases the value of incorrect answers //
            lblCorrect.Text = ("Correct : " + correct); // increases the value of correct answers //
            lblProbs.Text = ("Problem(s) :" + problem); // increases the value = to total number of problems //
            lblPercent.Text = ("Percent Correct :" + (correct / problem).ToString("P")); // gives the percentage of total correct answers //
        }


        private void NumberRange()
        {
            if (radSmall.Checked == true) // when range 1-12 is checked changes maxRange //
            {
                maxRange = 13;
            }
            else if (radLarge.Checked == true) // when range 1-24 is checked changes maxRange //
            {
               maxRange = 25;
            }

        }


    }
}
